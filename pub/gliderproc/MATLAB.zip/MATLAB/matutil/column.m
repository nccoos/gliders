
function b = column(a)
b = a(:);
return;
