% function [x,y]=ll2xy_yes(lat,lon)
function [x,y]=ll2xy_yes(lat,lon)
[x,y]=ll2xy(lat,lon,34.7847*pi/180.0,119.207*pi/180.0);
