figure('position',[550 15 500 500]);
whitebg('w');
orient tall;
wysiwyg;
set(gcf,'menubar','none');
hold on;
zoom on;
