% function [x,y]=ll2xy_adr(lat,lon)
% [x,y]=ll2xy(lat,lon,42.35*pi/180.0,16.00*pi/180.0)
function [x,y]=ll2xy_adr(lat,lon)
[x,y]=ll2xy(lat,lon,42.35*pi/180.0,16.00*pi/180.0);
