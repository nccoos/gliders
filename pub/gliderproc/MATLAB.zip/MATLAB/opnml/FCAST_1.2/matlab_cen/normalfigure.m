% figure('position',[400 400 600 500])
figure;
whitebg('w');
set(gcf,'menubar','none');
hold on;
zoom on;
