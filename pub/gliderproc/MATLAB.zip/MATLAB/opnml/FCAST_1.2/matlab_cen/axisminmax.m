axis([min(x) max(x) min(y) max(y)])
set(gca,'Box','on');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
axis('square')
