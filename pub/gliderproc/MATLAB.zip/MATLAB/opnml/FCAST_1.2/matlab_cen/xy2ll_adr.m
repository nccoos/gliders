% function [lat,lon]=xy2ll_adr(x,y)
% [lat,lon]=xy2ll(x,y,42.35*pi/180.0,16.00*pi/180.0)
function [lat,lon]=xy2ll_adr(x,y)
[lat,lon]=xy2ll(x,y,42.35*pi/180.0,16.00*pi/180.0);
