path(path,'/usr/yes/naimie/matlab_yes');
ls /usr/yes/naimie/matlab_yes
