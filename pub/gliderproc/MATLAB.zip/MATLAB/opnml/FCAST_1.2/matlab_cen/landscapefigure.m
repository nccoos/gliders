figure('position',[300 150 500 500]);
whitebg('w');
orient landscape;
wysiwyg;
set(gcf,'menubar','none');
hold on;


