%
% VORT - Compute the vorticity of a FEM 2-D vector field
%
%            THIS FUNCTION HAS BEEN REPLACED WITH CURL.
%            TYPE ">> help curl"
%
disp('THIS FUNCTION HAS BEEN REPLACED WITH CURL.')
disp('TYPE ">> help curl"')
