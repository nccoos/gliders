%READ_TRN read a .trn file as output from the OPNML transect code (obsolete)
%
% As of MATLAB5, this OPNML routine to read the .trn format output
% of the transect codes is obsolete.  Use READ_UCD.
%
disp('READ_TRN is obsolete. Use READ_UCD.')
