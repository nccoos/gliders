function [ data_qc, meta_qc ] = processQCGliderData( data_proc, meta_proc, varargin )
% TODO: This is to be completed later, for now is to add a default value to _QC
% variables for EGO formats

    data_qc = data_proc;
    meta_qc = meta_proc;

end

